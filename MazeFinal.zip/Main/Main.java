package Main;

import View.GUI;

import java.awt.*;

/**
 * Entry point of the application
 */
public class Main {
    /**
     * main method
     * @param args args
     * @throws AWTException a
     *
     */
    public static void main(String[] args) throws AWTException {
        GUI testGui = new GUI();//set up GUI
    }
}
