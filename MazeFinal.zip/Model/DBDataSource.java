package Model;

import Controller.Maze;
import Controller.Maze.*;
/**
    Interface for DBStatements that controls access to the database and it's required statements
*/
public class DBDataSource {
    /*
    Interface for DBStatements that controls access to the database and it's required statements
     */

//    void InsertData (String mazeName, String authorName, String creationDate)

}