package Model;

import Controller.IMaze;


/**
 * Used to for pre prepared SQL statements to add, search, edit, export and save mazes to the database
 */
public class MazeCollections {

    //implement this as a class between the GUI to add/delete for database etc



    /**
     * Used to add a maze to the database
     */
    public void addMaze()
    {
        return;
    }

    /**
     * Used to search for a maze in the database
     * @param maze maze object
     *
     */
    public void searchMaze(IMaze maze)
    {
        return;

    }

    /**
     * Used to edit a maze
     * @param maze maze object
     */
    public void editMaze(IMaze maze)
    {

        return;
    }

    /**
     * Used to export a maze from the database
     */
    public void exportMaze()
    {

        return;
    }

    /**
     * Used to save a maze to the database
     */
    public void saveMaze()
    {
        return;
    }
}